package com.example.penulisanilmiah;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {
    ImageButton BT1, BT2, BT3, BT4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(R.style.Theme_PenulisanIlmiah);
        setContentView(R.layout.activity_main);
        BT1 = (ImageButton) findViewById(R.id.imageButton1);
        BT2 = (ImageButton) findViewById(R.id.imageButton2);
        BT3 = (ImageButton) findViewById(R.id.imageButton3);
        BT4 = (ImageButton) findViewById(R.id.imageButton4);

        BT1.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                Intent i = new Intent(MainActivity.this, MapsActivity.class);
                startActivity(i);
            }
        });
        BT2.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                Intent i = new Intent(MainActivity.this, ListWisata.class);
                startActivity(i);
            }
        });
        BT3.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                Intent i = new Intent(MainActivity.this, History.class);
                startActivity(i);
            }
        });
        BT4.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                Intent i = new Intent(MainActivity.this, About.class);
                startActivity(i);
            }
        });
    }
}

