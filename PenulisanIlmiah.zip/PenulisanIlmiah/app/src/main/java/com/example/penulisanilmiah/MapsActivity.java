package com.example.penulisanilmiah;

import androidx.fragment.app.FragmentActivity;
import android.os.Bundle;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.example.penulisanilmiah.databinding.ActivityMapsBinding;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {
    private GoogleMap mMap;
    private ActivityMapsBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        LatLng Demak = new LatLng(-6.836991578327421, 110.63141801376574);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(Demak,9));
        LatLng Masjid = new LatLng(-6.8944368631935395, 110.6375786787358);
        mMap.addMarker(new MarkerOptions()
                .position(Masjid)
                .title("Masjid Agung Demak")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE))); //buat ganti ikon nya
        LatLng Kadilangu = new LatLng(-6.896307623631262, 110.64774572287656);
        mMap.addMarker(new MarkerOptions()
                .position(Kadilangu)
                .title("Masjid dan Makam Kadilangu")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_CYAN)));
        LatLng Syekh = new LatLng(-6.91431366687874, 110.48170343932331);
        mMap.addMarker(new MarkerOptions()
                .position(Syekh)
                .title("Makam Syekh Abdullah Mudzakir")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_MAGENTA)));
        LatLng HutanMangrove = new LatLng(-6.9158367251518165, 110.48275487006059);
        mMap.addMarker(new MarkerOptions()
                .position(HutanMangrove)
                .title("Hutan Mangrove Monosari")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_VIOLET)));

}}
